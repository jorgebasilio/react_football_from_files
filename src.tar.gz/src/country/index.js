import React, { Component } from 'react';
import {
  Card,
  CardActions,
  CardHeader,
  CardText
} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';

import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';

import style from './styles.css'

class Country extends Component {
  render() {
    const {value, options, handleChange, handleLayout} = this.props;
    const countries = options.map((value, index) => {
      return <MenuItem value={index} primaryText={value} key={index}/>
    })

    return(
      <div className='container'>
        <Card>
          <CardHeader
            title="Paises"
            subtitle="Selecciona un país"
            actAsExpander={true}
            showExpandableButton={true}
          />
          <DropDownMenu
            value={value}
            onChange={handleChange}
            autoWidth={false}
          >
            { countries }
          </DropDownMenu>
          <CardActions>
            <FlatButton label="Siguiente"
                        onClick={() => {handleLayout('leagues')}}/>
          </CardActions>
        </Card>
      </div>
    )
  }
}

export default Country;
