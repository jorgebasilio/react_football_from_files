import React, { Component, PropTypes } from 'react';
import AppBar from 'material-ui/AppBar';

import getMuiTheme from 'material-ui/styles/getMuiTheme';
import MyThemeDevToHack from './theme';

import Country from './../country/';
import League from './../league/index';

import style from './style.css';

const propTypes = {
  children: PropTypes.object,
};

class App extends Component {
  constructor() {
    super();
    this.state = {
      currentLayout: 'countries',
      country: 1,
      countryOptions: [
        'Venezuela',
        'Peru',
        'Colombia',
        'Chile'
      ],
      leagueOptions: {
        0: ['ligaVzla 1', 'ligaVzla 2', 'ligaVzla 3'],
        1: ['ligaPeru 1', 'ligaPeru 2', 'ligaPeru 3'],
        2: ['ligaColombia 1', 'ligaColombia 2', 'ligaColombia 3']
      },
      league: 0
    }
    this.handleChangeCountry = this.handleChangeCountry.bind(this);
    this.handleChangeLeague = this.handleChangeLeague.bind(this);
    this.handleChangeLayout = this.handleChangeLayout.bind(this);
  }
  getChildContext() {
      return {
        muiTheme: getMuiTheme(MyThemeDevToHack)
      }
  }

  handleChangeCountry(event, index, country) {
    this.setState({country});
  }

  handleChangeLeague(event, index, league) {
    this.setState({league});
  }

  handleChangeLayout(currentLayout) {
    this.setState({currentLayout});
  }

  render() {
    const {
      country,
      countryOptions,
      currentLayout,
      leagueOptions,
      league
    } = this.state;
    let layout;
    console.log(currentLayout);
    if(currentLayout === 'countries')
      layout = <Country value={country}
                        options={countryOptions}
                        handleChange={this.handleChangeCountry}
                        handleLayout={this.handleChangeLayout}/>
    if(currentLayout === 'leagues'){
      let leagueSelected = leagueOptions[country]
      layout = <League value={league}
        options={leagueSelected}
        handleChange={this.handleChangeLeague}
        handleLayout={this.handleChangeLayout}/>

    }
    return(
      <div>
        <AppBar title='Football'/>
        { layout }
      </div>
    );
  }
}

App.childContextTypes = {
  muiTheme: PropTypes.object.isRequired,
};

App.propTypes = propTypes;

export default App;
