import React, { Component } from 'react';
import {
  Card,
  CardActions,
  CardHeader,
  CardText
} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';

import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';

import style from './../country/styles.css'

class League extends Component {
  constructor() {
    super();
  }

  render() {
    const {value, options, handleChange, handleLayout} = this.props;

    const leagues = options.map((value, index) => {
      return <MenuItem value={index} primaryText={value} key={index}/>
    })

    return(
      <div className='container'>
        <Card>
          <CardHeader
            title="Ligas"
            subtitle="Selecciona una liga"
            actAsExpander={true}
            showExpandableButton={true}
          />
          <DropDownMenu
            value={value}
            onChange={handleChange}
            autoWidth={false}
          >
            { leagues }
          </DropDownMenu>
          <CardActions>
            <FlatButton label="Atras"
                         onClick={() => {handleLayout('countries')}} />
            <FlatButton label="Siguiente" />
          </CardActions>
        </Card>
      </div>
    )
  }
}

export default League;
